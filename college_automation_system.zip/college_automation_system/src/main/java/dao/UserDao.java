 package dao;
import java.sql.*; 
import entities.User;
public class UserDao {
  private Connection con;

public UserDao(Connection con) {
	this.con = con;
}
// method to insert user to databa..

	public boolean saveUser(User user) {
	    boolean f = false;

	    try {
	        String query = "INSERT INTO user (uname, upwd, uemail, umobile , utype) VALUES (?, ?, ?, ? ,?)";
	        PreparedStatement pstmt = this.con.prepareStatement(query);
	         pstmt.setString(1, user.getUname());
	        pstmt.setString(2, user.getUpwd());
	        pstmt.setString(3, user.getUemail());
	        pstmt.setString(4, user.getUmobile());
	        pstmt.setString(5, user.getUtype());

	        int rowsAffected = pstmt.executeUpdate();

	        if (rowsAffected > 0) {
	            f = true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return f;
	}
	
	// get User by useremail and userpassword
	
	public User getUserByEmailAndPassword(String uemail, String upwd){
		User user= null;
		try {
			String q="select * from user where uemail=? and upwd=?";
		    PreparedStatement pstmt =con.prepareStatement(q);
		    pstmt.setString(1,uemail);
		    pstmt.setString(2,upwd) ;
		
		ResultSet set =pstmt.executeQuery();
		if(set.next())
		{
			user=new User();
			int id=set.getInt("uid");
			user.setUid(id);
			String name=set.getString("uname");
			user.setUname(name);
			String password=set.getString("upwd");
			user.setUpwd(password);
			String email=set.getString("uemail");
			user.setUemail(email);
			String mobile=set.getString("umobile");
			user.setUmobile(mobile);
			String type=set.getString("utype");
			user.setUtype(type);

 		}
		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		return user;

	}	
}


