package entities;

public class User {
    private int uid;
    private String uname;
    private String upwd;
    private String uemail;
    private String umobile;
    private String utype;

    public User(int uid, String uname, String upwd, String uemail, String umobile, String utype) {
        this.uid = uid;
        this.uname = uname;
        this.upwd = upwd;
        this.uemail = uemail;
        this.umobile = umobile;
        this.utype = utype;
    }

    public User() {
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;  
    }  

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getUpwd() {
        return upwd;
    }

    public void setUpwd(String upwd) {
        this.upwd = upwd;
    }

    public String getUemail() {
        return uemail;
    }

    public void setUemail(String uemail) {
        this.uemail = uemail;
    }

    public String getUmobile() {
        return umobile;
    }

    public void setUmobile(String umobile) {
        this.umobile = umobile;
    }

    public String getUtype() {
        return utype;
    }

    public void setUtype(String utype) {
        this.utype = utype;
    }

    public User(String uname, String upwd, String uemail, String umobile, String utype) {
        this.uname = uname;
        this.upwd = upwd;
        this.uemail = uemail;
        this.umobile = umobile;
        this.utype = utype;
    }

    @Override
    public String toString() {
        return "User(" + "uid=" + uid + ", uname=" + uname + ", upwd=" + upwd + ", uemail=" + uemail + ", umobile=" + umobile + ", utype=" + utype + ")";
    }
}
