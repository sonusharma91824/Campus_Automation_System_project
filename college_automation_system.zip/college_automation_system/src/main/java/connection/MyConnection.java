package connection;
import java.sql.*;
import java.sql.DriverManager;

public class MyConnection {



	
	   private static Connection con ;  
	   public static Connection getConnection()
	   {
	      try
	      {
	    	  if(con==null) {
	 	        Class.forName("com.mysql.cj.jdbc.Driver");
			    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college_project","root","");
	      }
	      }
	       catch (Exception e) 
	       {
		       System.out.println("Connection Exception is : "+e.toString());
		    }
	     return con;
	}
	}

