package servlet;

import entities.User;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Registration;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connection.MyConnection;
import dao.UserDao;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Registration</title>");
            out.println("</head>");
            out.println("<body>");

            String check = request.getParameter("check");
            if (check == null) {
                out.print("click to agree terms & conditions");
            } else {
                String name = request.getParameter("user_name");
                String password = request.getParameter("user_password");
                String email = request.getParameter("user_email");
                String mobile = request.getParameter("user_mobile");

                // Create a user object and set all data to that object
                User user = new User();
                user.setUname(name);
                user.setUpwd(password);
                user.setUemail(email);
                user.setUmobile(mobile);
                user.setUtype("normal");

                // Create a UserDao object
                UserDao dao = new UserDao(MyConnection.getConnection());
                
                if (dao.saveUser(user)) {
                    out.println("Registration Successful");
                    response.sendRedirect("LoginPage.jsp");

                } else {
                    out.print("Error occurred during registration");
                }
            }
            out.println("</body>");
            out.println("</html>");
        }
    }
}
