package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import connection.MyConnection;
import dao.UserDao;
import entities.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");

        try (PrintWriter out = response.getWriter()) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            // Validation

            // Authenticating user
            UserDao userDao = new UserDao(MyConnection.getConnection());
            User user = userDao.getUserByEmailAndPassword(email, password);
            System.out.print(user);
            
            if (user == null) {
                out.println("<h1>Invalid details</h1>");
                response.sendRedirect("Error.jsp");
            } else {
                out.println("<h1>Welcome</h1>");
                HttpSession httpSession = request.getSession();
                httpSession.setAttribute("current-user", user);

                if ("admin".equals(user.getUtype())) {
                    response.sendRedirect("admin.jsp");
                } else if ("facult".equals(user.getUtype())) {
                    response.sendRedirect("Faculty.jsp");
                } else if ("placement_coordinator".equals(user.getUtype())) {
                    response.sendRedirect("Placement_Coordinator.jsp");
                } else {
                    response.sendRedirect("Student.jsp");
                }
            }
        }
    }
}
